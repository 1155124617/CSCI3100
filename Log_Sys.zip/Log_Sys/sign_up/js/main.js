
(function ($) {
    "use strict";

    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit',function(){
        var check = true;

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
            }
        }
        
        
        if(check)
        {
            $.ajax({
                async: false,
                url:"http://localhost:8081/reg",
                type:"GET",
                data:{
                    username: $(input[0]).val(),
                    password: $(input[1]).val()
                }
            }).
            always(function(txt){
                if (txt.responseText == "S"){
                    alert("Sign up successfully!");
                }
                else{
                    alert("Sign up failed! Please try another username!");
                    check=false;
                }
                
            });
        }
        return check;
    });


    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        }
        if ($(input).attr('name') == 'username'){
            if($(input).val().trim() == '')
            {
                $('#reg_username_text').text("Empty username!");
                return false;
            }
            else if($(input).val().length < 5 || $(input).val().length > 16){
                $('#reg_username_text').text("Please enter 5-16 letters or numbers as your username!");
                return false;
            }
            else{
                $('#reg_username_text').text("");
            }
        }
        if ($(input).attr('name') == 'pass'){
            if($(input).val().trim() == '')
            {
                $('#reg_password_text').text("Empty password!");
                return false;
            }
            else if($(input).val().length < 5 || $(input).val().length > 16){
                $('#reg_password_text').text("Please enter 5-16 letters or numbers as your password!");
                return false;
            }
            else{
                $('#reg_password_text').text("");
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();
        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();
        $(thisAlert).removeClass('alert-validate');
    }
    
    

})(jQuery);
