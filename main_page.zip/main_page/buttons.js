
(function ($) {
    "use strict";
    /*==================================================================
    [ Validate ]*/

    window.onload=function(){
        if ($.cookie("username") === undefined) {
            alert("You already logout, please log in first!");
            window.location.replace("../sign_in/index.html");
        }
        else {
            $("#helloUser").text("hello, " + $.cookie("username") + " !  ");
            $(".username").text($.cookie("username"));
        }

        
        $('#logout').click(function(){
            $.removeCookie("username", {path:'/'});
        });
        
    };

})(jQuery);


