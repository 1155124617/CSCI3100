
var express=require("express");
var events = require('events');
var emitter = new events.EventEmitter();
var app=express();
var path=require("path");
var mysql=require("mysql");
var dirname=__dirname;
app.use(express.static(path.join(__dirname, 'project')));
    
app.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By", ' 3.2.1');
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
});

app.all('*', (req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*")
    req.method == "Options" ? res.send(200) : next()
});

app.get("/reg",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();

    
    emitter.on("ok",function(){
        return res.end("S");
    });
    emitter.on("false",function(){
        return res.end("F");
    });
    
    var sql="insert into user(username,password) values(?,?)";
    var sqlValue=[req.query.username, req.query.password];

    connection.query(sql,sqlValue,function(err){
        if(err){
            console.log(err.message);
            emitter.emit("false");
        }
        else
        {
            emitter.emit("ok");
        }
    });
    connection.end();
});
app.listen(8081);
