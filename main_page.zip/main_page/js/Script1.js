
// JavaScript source code for DevTour game system
// Initial design of game book page interface
var number = 19;
var hash = new Array();
var username = $.cookie("username");
for (var i = 0; i < 4; i++) {
    hash[i] = 0;
}
//Class design for game system
//Game class design
var Game = {
    UID: username,
    //Initialize all the status with 50
    physical_health: 50,
    mental_health: 50,
    money: 50,
    academic: 50,
    //Keep the question ID record
    question_ID: 0,
    //Keep the game round record
    round: 0,
    //Keep the control of different style of question (with different UI style)
    flag: 1,
    //Update the question_ID for the game progress
    ask_question: function (number) {
        this.question_ID++;
    },
    update_physical: function (point) {
        //Update the status value
        this.physical_health += point;
        //Change the color based on the value to remind the player about the situation
        //Specially, when the value is high, the color is green
        //When the value is medium, the color is yellow
        //When the value is low, the color is red
        //Finally when we lost all points for this status, the color is black
        if (this.physical_health >= 100) {
            this.physical_health = 100;
        }
        if (this.physical_health >= 66) {
            document.getElementById("physical").style.color = "green";
            document.getElementById("physical1").style.color = "green";
        }
        if (this.physical_health < 66 && this.physical_health > 33) {
            document.getElementById("physical").style.color = "goldenrod";
            document.getElementById("physical1").style.color = "goldenrod";
        }
        if (this.physical_health <= 33 && this.physical_health > 0) {
            document.getElementById("physical").style.color = "red";
            document.getElementById("physical1").style.color = "red";
        }
        if (this.physical_health <= 0) {
            document.getElementById("physical").style.color = "black";
            document.getElementById("physical1").style.color = "black";
        }
    },
    update_mental: function (point) {
        //Update the status value
        this.mental_health += point;
        //Change the color based on the value to remind the player about the situation
        //Specially, when the value is high, the color is green
        //When the value is medium, the color is yellow
        //When the value is low, the color is red
        //Finally when we lost all points for this status, the color is black
        if (this.mental_health >= 100) {
            this.mental_health = 100;
        }
        if (this.mental_health >= 66) {
            document.getElementById("mental").style.color = "green";
            document.getElementById("mental1").style.color = "green";
        }
        if (this.mental_health < 66 && this.mental_health > 33) {
            document.getElementById("mental").style.color = "goldenrod";
            document.getElementById("mental1").style.color = "goldenrod";
        }
        if (this.mental_health <= 33 && this.mental_health > 0) {
            document.getElementById("mental").style.color = "red";
            document.getElementById("mental1").style.color = "red";
        }
        if (this.mental_health <= 0) {
            document.getElementById("mental").style.color = "black";
            document.getElementById("mental1").style.color = "black";
        }
    },
    update_money: function (point) {
        //Update the status value
        this.money += point;
        //Change the color based on the value to remind the player about the situation
        //Specially, when the value is high, the color is green
        //When the value is medium, the color is yellow
        //When the value is low, the color is red
        //Finally when we lost all points for this status, the color is black
        if (this.money >= 100) {
            this.money = 100;
        }
        if (this.money >= 66) {
            document.getElementById("money").style.color = "green";
            document.getElementById("money1").style.color = "green";
        }
        if (this.money < 66 && this.money > 33) {
            document.getElementById("money").style.color = "goldenrod";
            document.getElementById("money1").style.color = "goldenrod";
        }
        if (this.money <= 33 && this.money > 0) {
            document.getElementById("money").style.color = "red";
            document.getElementById("money1").style.color = "red";
        }
        if (this.money <= 0) {
            document.getElementById("money").style.color = "black";
            document.getElementById("money1").style.color = "black";
        }
    },
    update_academic: function (point) {
         //Update the status value
        this.academic += point;
        //Change the color based on the value to remind the player about the situation
        //Specially, when the value is high, the color is green
        //When the value is medium, the color is yellow
        //When the value is low, the color is red
        //Finally when we lost all points for this status, the color is black
        if (this.academic >= 100) {
            this.academic = 100;
        }
        if (this.academic >= 66) {
            document.getElementById("academic").style.color = "green";
            document.getElementById("academic1").style.color = "green";
        }
        if (this.academic < 66 && this.academic > 33) {
            document.getElementById("academic").style.color = "goldenrod";
            document.getElementById("academic1").style.color = "goldenrod";
        }
        if (this.academic <= 33 && this.academic > 0) {
            document.getElementById("academic").style.color = "red";
            document.getElementById("academic1").style.color = "red";
        }
        if (this.academic <= 0) {
            document.getElementById("academic").style.color = "black";
            document.getElementById("academic1").style.color = "black";
        }
    },
    game_over: function () {
        //Check whether the game is over or not
        //When one of the status goes down to 0 or the player pass all the rounds, the game is over.
        //If it is over, post the game over information to the server
        if (this.physical_health <= 0 || this.mental_health <= 0 || this.money <= 0 || this.academic <= 0) {
            $.ajax({
                url: "/main_page/record",
                type: "POST",
                async: false,
                data: {
                    UID: username,
                    round: Game.round
                },
                success: (function (txt) { console.log(username); })
            });
            setTimeout("popout()", 1000);
            return 1;
        } else if (this.round >= 19) {
            $.ajax({
                url: "/main_page/record",
                type: "POST",
                async: false,
                data: {
                    UID: username,
                    round: Game.round
                },
                success: (function (txt) { console.log(username); })
            });
            setTimeout("popout1()", 1000);
        }
        return 0;
    }
};
//User-friendly reminder
function popout() {
    alert("Your game is over. Press 'Close' to start a new game.");
    location.reload(true);
}
function popout1(){
    alert("You have completed all tasks and overcomed all obstacles! Press 'Close' to start a new game.");
    location.reload(true);
}
//Keep the question information
//Event class design
var Event1 = {
    question_ID: 0,
    title: "Your Best Friend",
    content: "Do you wanna go for a gym?",
    img: "images/3.jpg",
    physical_1: 20,
    physical_2: 0,
    mental_1: 15,
    mental_2: 0,
    money_1: -15,
    money_2: 0,
    academic_1: 0,
    academic_2: 0

}
var Event2 = {
    question_ID: 1,
    title: "Your Target",
    content: "Let's go for a date tonight.",
    img: "images/1.jpg",
    physical_1: -15,
    physical_2: 0,
    mental_1: 20,
    mental_2: 0,
    money_1: -25,
    money_2: 0,
    academic_1: -10,
    academic_2: 10
}
var Event3 = {
    question_ID: 2,
    title: "Your Professor",
    content: "Do you wanna have a lunch talk with me?",
    img: "images/2.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: -10,
    mental_2: 0,
    money_1: 0,
    money_2: 10,
    academic_1: 25,
    academic_2: -15
}
var Event4 = {
    question_ID: 3,
    title: "The Final Exam is comming!",
    content: "You have just downloaded the newest 'Monster hunter' Game and you have to struggle to choose whether playing the game or reviewing for the exam. Do you wanna play the game?",
    img: "images/4.jpg",
    physical_1: -5,
    physical_2: -5,
    mental_1: 10,
    mental_2: 10,
    money_1: -20,
    money_2: 0,
    academic_1: -30,
    academic_2: 25
}

var Event5 = {
    question_ID: 4,
    title: "Basketball or research discussion",
    content: "Today is Sunday. Your professor tells you that there is a research activity for you and wants you to come to his office for discussing. However, you have made an appointment with your friends playing basketball.Dou wanna play basket?",
    img: "images/3.jpg",
    physical_1: 15,
    physical_2: 0,
    mental_1: 10,
    mental_2: 10,
    money_1: -15,
    money_2: 0,
    academic_1: -20,
    academic_2: 15

}

var Event6 = {
    question_ID: 5,
    title: "Goddess or homework",
    content: "Your goddess called you today and told you that she wants go to watch a new movie. However, you have a homework after tomorrow which is time-consuming.Do you wanna go dating?",
    img: "images/5.jpg",
    physical_1: 0,
    physical_2: 0,
    mental1: 20,
    mental2: -15,
    money_1: -20,
    money_2: 0,
    academic_1: -15,
    academic_2: 10

}

var Event7 = {
    question_ID: 6,
    title: "Japanese food or preparing exam ",
    content: "Your friends asked you to have dinner of Japanese food together in Mong Kok. However, you are facing an exam after next week. Do you wanna go for the Japanese food?",
    img: "images/3.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: 25,
    mental_2: -10,
    money_1: -20,
    money_2: 0,
    academic_1: -20,
    academic_2: 15,

}

var Event8 = {
    question_ID: 7,
    title: "Web design",
    content: " Someone asks you to design a web for his/her. However this is a time-consuming work. If you take this, obviously part of your study time will be occupied. What is your choice?",
    img: "images/4.jpg",
    physical_1: -5,
    physical_2: 0,
    mental_1: -5,
    mental_2: 0,
    money_1: 15,
    money_2: 0,
    academic_1: -5,
    academic_2: 0,
}

var Event9 = {
    question_ID: 8,
    title: "Tutor",
    content: "Your uncle wants to teach his son primary mathematics twice a week and one time lasts for 2 hours. If you do not take, your uncle and his son will be unhappy about that. Would you take this?",
    img: "images/4.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: 5,
    mental_2: -5,
    money_1: 10,
    money_2: 0,
    academic_1: -5,
    academic_2: 0,

}

var Event10 = {
    question_ID: 8,
    title: "Study or sleep",
    content: " This evening you feel unwell and have headache. This is because you do not get enough sleep last night. However you have deadline of homework after tomorrow. Will you go to sleep or continue to study and finish your homework?",
    img: "images/4.jpg",
    physical_1: 5,
    physical_2: -5,
    mental_1: 10,
    mental_2: -10,
    money_1: 0,
    money_2: 0,
    academic_1: -5,
    academic_2: 5,

}

var Event11 = {
    question_ID: 9,
    title: "Continue to solve difficult problem��",
    content: " You are a big fan of algorithm and facing several very difficult algorithm problems which are not include in your course scope. You have already trying to solve them for few days. Also you only have time to do this after 10 pm. Will you continue to solve them?",
    img: "images/4.jpg",
    physical_1: -10,
    physical_2: 5,
    mental_1: -15,
    mental_2: 5,
    money_1: 0,
    money_2: 0,
    academic_1: 20,
    academic_2: 0,

}

var Event12 = {
    question_ID: 10,
    title: "Fitness test",
    content: " Today is Saturday. You are lying in bed, reading a novel, and suddenly remembered that there will be a physical fitness test (will affect your GPA) next Monday.",
    img: "images/4.jpg",
    physical_1: -10,
    physical_2: 5,
    mental_1: 10,
    mental_2: -10,
    money_1: 0,
    money_2: 0,
    academic_1: -10,
    academic_2: 10,

}

var Event13 = {
    question_ID: 11,
    title: "Obesity and sweets",
    content: " Your medical examination report shows that you have obesity. doctor told you that you cannot eat sweets anymore. However, you want to eat cheesecake now.",
    img: "images/4.jpg",
    physical_1: 10,
    physical_2: -10,
    mental_1: -10,
    mental_2: 10,
    money_1: 0,
    money_2: -5,
    academic_1: 0,
    academic_2: 0,

}

var Event14 = {
    question_ID: 12,
    title: "Teaching assistant",
    content: " Your mentor invites you to be his teaching assistant. You need to go to his laboratory every Saturday and Sunday to do data analysis. He promised to you that he will give you subsidy and recommendation letter. Will you be his TA?",
    img: "images/4.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: -15,
    mental_2: 5,
    money_1: 10,
    money_2: 0,
    academic_1: 15,
    academic_2: 0,

}

var Event15 = {
    question_ID: 13,
    title: " GPA",
    content: "Your mother promised you that if you can achieve a GPA of 3.5 or higher next semester, she will give you a reward of 5,000 HKD. But if the GPA is lower than it is now, she will deduct your pocket money. Will you study harder next semester?",
    img: "images/4.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: -15,
    mental_2: 10,
    money_1: 15,
    money_2: -10,
    academic_1: 10,
    academic_2: -5,

}

var Event16 = {
    question_ID: 14,
    title: "Internship",
    content: "You got an opportunity to have a Tencent internship. If you accept this internship, you will have to skip the CSCI3100 class every Wednesday morning. Will you accept?",
    img: "images/4.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: 0,
    mental_2: 0,
    money_1: 15,
    money_2: 0,
    academic_1: -15,
    academic_2: 0,

}

var Event17 = {
    question_ID: 15,
    title: "How to go school",
    content: "You got up late today and missed a minibus 282S which is the only minibus from your home to CUHK. Will you take a taxi, or continue to wait for the next minibus but will be half an hour late for class?",
    img: "images/4.jpg",
    physical_1: 0,
    physical_2: 0,
    mental_1: 0,
    mental_2: 0,
    money_1: -10,
    money_2: -5,
    academic_1: 5,
    academic_2: -5,

}

var Event18 = {
    question_ID: 16,
    title: "Project",
    content: " Your teacher asks you to do a project that involves some professional knowledge that you have not learned yet. Are you going to stay up for a few days to search information by yourself, or find an expert to teach you?",
    img: "images/4.jpg",
    physical_1: -10,
    physical_2: 0,
    mental_1: -10,
    mental_2: 5,
    money_1: 0,
    money_2: -20,
    academic_1: 10,
    academic_2: 15,

}

var Event19 = {
    question_ID: 17,
    title: " Phone",
    content: " The screen of your phone is broken. Although it is still usable, the broken part makes it difficult for you to see clearly. You find that your eyes hurt after watching this screen for a long time. Will you continue to use it, or buy a new phone?",
    img: "images/4.jpg",
    physical_1: -10,
    physical_2: 5,
    mental_1: 0,
    mental_2: 5,
    money_1: 10,
    money_2: -10,
    academic_1: -5,
    academic_2: 5,

}


//Question class design
var question = [Event1, Event2, Event3, Event4, Event5, Event6, Event7, Event8, Event9, Event10, Event11, Event12, Event13, Event14, Event15, Event16, Event17, Event18, Event19];
//Game page
$(document).ready(function () {
    //Show the game appropriately
    $("img.page1").attr('src', question[Game.question_ID].img);
    $("h1.page1").html(question[Game.question_ID].title);
    $("p.page1").html(question[Game.question_ID].content);
    //If the player choose disagree
    //the information will be updated accordingly
    $(".disagree").click(function () {
        Game.round++;
        hash[Game.question_ID] = 1;
        Game.update_physical(question[Game.question_ID].physical_2);
        Game.update_mental(question[Game.question_ID].mental_2);
        Game.update_money(question[Game.question_ID].money_2);
        Game.update_academic(question[Game.question_ID].academic_2);
        if (Game.game_over() == 0) {
            while (hash[Game.question_ID] == 1) {
                Game.ask_question(number);
                console.log(Game.question_ID);
            }
            if (Game.flag == 1) {
                $("img.page2").attr('src', question[Game.question_ID].img);
                $("h1.page2").html(question[Game.question_ID].title);
                $("p.page2").html(question[Game.question_ID].content);
            } else {
                $("img.page1").attr('src', question[Game.question_ID].img);
                $("h1.page1").html(question[Game.question_ID].title);
                $("p.page1").html(question[Game.question_ID].content);
            }
            Game.flag = 1 - Game.flag;
        }
    });
    //If the player choose agree
    //the information will be updated accordingly
    $(".agree").click(function () {
        Game.round++;
        hash[Game.question_ID] = 1;
        Game.update_physical(question[Game.question_ID].physical_1);
        Game.update_mental(question[Game.question_ID].mental_1);
        Game.update_money(question[Game.question_ID].money_1);
        Game.update_academic(question[Game.question_ID].academic_1);
        if (Game.game_over() == 0) {
            while (hash[Game.question_ID] == 1) {
                Game.ask_question(number);
                console.log(Game.question_ID);
            }
            if (Game.flag == 1) {
                $("img.page2").attr('src', question[Game.question_ID].img);
                $("h1.page2").html(question[Game.question_ID].title);
                $("p.page2").html(question[Game.question_ID].content);
            } else {
                $("img.page1").attr('src', question[Game.question_ID].img);
                $("h1.page1").html(question[Game.question_ID].title);
                $("p.page1").html(question[Game.question_ID].content);
            }
            Game.flag = 1 - Game.flag;
        }
    });
    //If the player click to save, the game progress information will be sent to the server
    $(".save").click(function () {
        $.ajax({
            url: "/main_page/savefile",
            type: "POST",
            data: {
                UID: username,
                physical: Game.physical_health,
                mental: Game.mental_health,
                money: Game.money,
                academic: Game.academic,
                round: Game.round
            },
            success: (function (txt) { console.log(Game.flag); })
        });
        //User-friendly reminder
        alert("Save success!");
    })
    //If the player click to load, the game progress information will be retrieved from the server
    $(".load").click(function () {
        $.ajax({
            url: "/main_page/loadfile",
            type: "POST",
            data: {
                UID: username
            },
            async: false,
            success: (function (data) {
                //Successfully retireve the correct information and the game page can be real-time updated accordingly
                Game.physical_health = data[0].physical;
                Game.mental_health = data[0].mental;
                Game.money = data[0].money;
                Game.academic = data[0].academic;
                Game.round = data[0].round;
                Game.question_ID = Game.round;
                $("img.page1").attr('src', question[Game.question_ID].img);
                $("h1.page1").html(question[Game.question_ID].title);
                $("p.page1").html(question[Game.question_ID].content);
                //The text style will also be updated
                Cufon.replace('h1,h2,p,.b-counter');
                Cufon.replace('.book_wrapper a', { hover: true });
                Cufon.replace('.title', { textShadow: '1px 1px #C59471', fontFamily: 'ChunkFive' });
                Cufon.replace('.reference a', { textShadow: '1px 1px #C59471', fontFamily: 'ChunkFive' });
                Cufon.replace('.loading', { textShadow: '1px 1px #000', fontFamily: 'ChunkFive' });
            })
        });
        document.getElementById("mybook").style.display = "none";
        //User-friendly reminder
        alert("Load success!");
        document.getElementById("mybook").style.display = "block";
        console.log(Game.physical_health, Game.mental_health, Game.money, Game.academic, Game.round);
    })
    //If the player click to check the records of the other players, the record information will be retrieved from the server
    $(".check").click(function () {
        //The record information display region intialization
        var s1 = $("#status1").html();
        var s2 = $("#status2").html();
        if (s1.length != 0 || s2.length != 0) {
            if (Game.flag == 1 && s1.length != 0) {
                $("#status1").html("");
            }
            else {
                if (Game.flag != 1 && s2.length != 0) {
                    $("#status2").html("");
                }
            }
        }
        else {
            //Successfully retieve the information and display the record in the corresponding position
            $.ajax({
                url: "/main_page/checkrecord",
                type: "GET",
                async: true,
                success: (function (data) {
                    console.log(data);
                    $("#status1").html("");
                    $("#status2").html("");
                    if (Game.flag == 1) {
                        for (var i = 0; i < data.length; i++) {
                            var son = document.createElement("div");
                            son.innerHTML = "<p>&nbsp &nbsp Rank" + (i + 1) + " Name:" + data[i].UID + " Round: " + data[i].round + "</p>";
                            document.getElementById('status1').appendChild(son);
                            Cufon.replace('p');
                            if (i >= 3) {
                                break;
                            }
                        }
                    } else {
                        for (var i = 0; i < data.length; i++) {
                            var son = document.createElement("div");
                            son.innerHTML = "<p>&nbsp &nbsp Rank" + (i + 1) + " Name:" + data[i].UID + " Round: " + data[i].round + "</p>";
                            document.getElementById('status2').appendChild(son);
                            Cufon.replace('p');
                            if (i >= 3) {
                                break;
                            }
                        }
                    }
                })
            });
        }
    })
});

