
var express=require("express");
var events = require('events');
var emitter = new events.EventEmitter();
var app=express();
var path=require("path");
var mysql=require("mysql");
var dirname=__dirname;
const bodyParser=require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'project')));
    
app.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By", ' 3.2.1');
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
});

app.all('*', (req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*")
    req.method == "Options" ? res.send(200) : next()
});

app.post("/reg",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();
    
    var sql="insert into user(username,password) values(?,?);";
    var sqlValue=[req.body['username'], req.body['password']];

    connection.query(sql,sqlValue,function(err){
        if(err){
            console.log(err.message);
            return res.end("F");
        }
        else if(!err)
        {
            return res.end("S");
        }
    });
});

app.post("/log",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();
    var sql="select * from user where username=? and password=?;";
    var sqlValue=[req.body['username'], req.body['password']];
    
    connection.query(sql,sqlValue,function(err,result){
        if(err){
            console.log("error!");
            console.log(err.message);
            return res.end("E");
        }
        else if(!err)
        {
            if(result.length == 1)
            {
                return res.end("S");
            }
            else
            {
                return res.end("F");
            }
        }
    });
});

app.post("/admin_log",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();
    var sql="select * from admin where username=? and password=?;";
    var sqlValue=[req.body['username'], req.body['password']];
    
    connection.query(sql,sqlValue,function(err,result){
        if(err){
            console.log("error!");
            console.log(err.message);
            return res.end("E");
        }
        else if(!err)
        {
            if(result.length == 1)
            {
                return res.end("S");
            }
            else
            {
                return res.end("F");
            }
        }
    });
});

app.post("/admin_user_c",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();
    
    var sql="insert into user(username,password) values(?,?);";
    var sqlValue=[req.body['username'], req.body['password']];

    connection.query(sql,sqlValue,function(err){
        if(err){
            console.log(err.message);
            return res.end("F");
        }
        else if(!err)
        {
            return res.end("S");
        }
    });
});

app.post("/admin_user_d",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();
    
    var sql="delete from user where username=?;";
    var sqlValue=[req.body['username']];

    connection.query(sql,sqlValue,function(err, result){
        if(err){
            console.log("error!");
            console.log(err.message);
            return res.end("E");
        }
        else if(!err)
        {
            if(result.affectedRows == 1)
                return res.end("S");
            else
                return res.end("F");
        }
    });
});

app.post("/admin_user_u",function(req,res){

    var connection=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"yy990525",
        database:"CSCI3100"
    });

    connection.connect();
    
    var sql="update user set username=?, password=? where username=?";
    var sqlValue=[req.body['n_username'], req.body['n_password'], req.body['o_username']];

    connection.query(sql,sqlValue,function(err, result){
        if(err){
            console.log("error!");
            console.log(err.message);
            return res.end("E");
        }
        else if(!err)
        {
            if(result.affectedRows == 1)
                return res.end("S");
            else
                return res.end("F");
        }
    });
});

app.listen(8081);
